package com.springboot.jpa.persistence;

import org.springframework.data.repository.CrudRepository;

import com.springboot.jpa.entity.Board;

// Board 게시글 타입 Long 식별자 타입
public interface BoardRepository extends CrudRepository<Board, Long>{

	
}

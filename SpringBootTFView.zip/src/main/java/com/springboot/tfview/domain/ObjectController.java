package com.springboot.tfview.domain;



import java.sql.Timestamp;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ObjectController {

	@GetMapping("/object")
	public void hello(Model model) {
		MemberVO vo = new MemberVO(1, "jangnara", "1234", "장나라", new Timestamp(System.currentTimeMillis()));
		
		model.addAttribute("vo", vo);
	}
}

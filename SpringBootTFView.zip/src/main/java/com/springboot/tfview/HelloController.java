package com.springboot.tfview;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

public class HelloController {

	@GetMapping(value= {"/", "/hello"})
	public String hello(Model model) {
//		model.addAttribute("data","Hello~jangnara");
		model.addAttribute("data","안녕, 장나라");
		return "hello";
	}
}

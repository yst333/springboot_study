package com.springboot.tfview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootTfViewApplicationTests {

	@Test
	void contextLoads() {
	}

}

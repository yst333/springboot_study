package com.springboot.react;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackEndSpringBootCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackEndSpringBootCrudApplication.class, args);
	}

}

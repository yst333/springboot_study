package com.springboot.react.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.springboot.react.model.Article;

@Repository
public interface ArticleRepository extends CrudRepository<Article, Integer> {
	
	Article findTopByOrderByArticleIdDesc(); // 최신글 조회 활용 추상 메소드
	
	Article save(Article article); // 등록, 수정 처리 추상 메소드
	
	void delete(Article article); // 삭제 처리 추상 메소드
}

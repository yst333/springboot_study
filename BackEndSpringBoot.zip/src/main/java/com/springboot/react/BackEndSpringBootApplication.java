package com.springboot.react;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackEndSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackEndSpringBootApplication.class, args);
	}

}
